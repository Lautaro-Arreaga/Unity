using UnityEngine;

public class BulletController : MonoBehaviour
{
    void OnCollisionEnter2D(Collision2D collision)
    {
        // Si la bala colisiona con un objeto con el tag "ItemBad"
        if (collision.gameObject.CompareTag("ItemBad"))
        {
            Destroy(collision.gameObject);  // Destruye el objeto "ItemBad"
            Destroy(gameObject);  // Destruye la bala
        }
    }
}
