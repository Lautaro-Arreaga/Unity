using UnityEngine;

public class DeathZone : MonoBehaviour
{
    public int damageAmount = 100; // Daño que recibe el jugador al tocar la DeathZone

    // Este método se ejecuta cuando otro objeto entra en el área de la DeathZone
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Verificamos si el objeto que toca la zona tiene el tag "Player" o "TargetPlayer"
        if (collision.CompareTag("Player") || collision.CompareTag("TargetPlayer")) 
        {
            // Obtener la referencia al script PlayerHealth del jugador
            PlayerHealth playerHealth = collision.GetComponent<PlayerHealth>();

            if (playerHealth != null)
            {
                // Llamar al método TakeDamage y aplicar el daño a la salud del jugador
                playerHealth.TakeDamage(damageAmount);
            }
        }
    }
}

