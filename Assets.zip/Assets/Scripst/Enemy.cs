using UnityEngine;

public class Enemy : MonoBehaviour
{
    public GameObject explosionEffect; // Prefab del efecto de explosión
    public int damageToPlayer = 1; // Daño que este enemigo causa al jugador
    public int health = 3;  // Salud del enemigo

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Verificar si el objeto que colisiona es el jugador
        if (other.CompareTag("Player"))
        {
            // Instanciar el efecto de explosión si está asignado
            if (explosionEffect != null)
            {
                Instantiate(explosionEffect, transform.position, Quaternion.identity);
            }

            // Llamar a una función para dañar al jugador (si existe)
            PlayerMOVE player = other.GetComponent<PlayerMOVE>();
            if (player != null)
            {
                player.TakeDamage(damageToPlayer);
            }

            // Destruir este enemigo
            Destroy(gameObject);
        }

        // Verificar si el objeto que colisiona es una bala
        if (other.CompareTag("Bullet"))
        {
            // Instanciar el efecto de explosión si está asignado
            if (explosionEffect != null)
            {
                Instantiate(explosionEffect, transform.position, Quaternion.identity);
            }

            // Destruir el enemigo
            Destroy(gameObject);
        }
    }

    public void TakeDamage(int damage)
    {
        // Reduce la salud del enemigo
        health -= damage;

        // Si la salud llega a cero o menos, destruye al enemigo
        if (health <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        // Instanciar el efecto de explosión si está asignado
        if (explosionEffect != null)
        {
            Instantiate(explosionEffect, transform.position, Quaternion.identity);
        }

        // Destruir el enemigo
        Destroy(gameObject);
    }
}
