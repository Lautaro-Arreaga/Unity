using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro; // Asegúrate de agregar esta línea

public class GameManager : MonoBehaviour
{
    public int score = 0; // Puntaje inicial
    public TextMeshProUGUI textScore; // Cambiado a TextMeshProUGUI
    public TextMeshProUGUI gameOverText; // Cambiar si también usas TextMeshPro
    public GameObject restartButton;

    private bool isGameOver = false;

    void Start()
    {
        UpdateScoreUI();
        if (gameOverText != null) gameOverText.gameObject.SetActive(false);
        if (restartButton != null) restartButton.SetActive(false);
    }

    public void AddScore()
    {
        if (!isGameOver)
        {
            score++;
            UpdateScoreUI();
        }
    }

    private void UpdateScoreUI()
    {
        if (textScore != null)
        {
            textScore.text = "Score: " + score;
        }
    }

    public void GameOver()
    {
        isGameOver = true;
        if (gameOverText != null) gameOverText.gameObject.SetActive(true);
        if (restartButton != null) restartButton.SetActive(true);
    }

    public void RestartGame()
    {
        score = 0;
        isGameOver = false;
        Time.timeScale = 1f;

        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}


