using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class PlayerMOVE : MonoBehaviour
{
    public float playerJumpForce = 10f;  // Fuerza del salto
    public float playerSpeed = 5f;      // Velocidad del jugador
    public Sprite[] mySprites;          // Array de sprites para la animación
    private int index = 0;              // Índice para cambiar de sprite

    private Rigidbody2D myRigidbody2D;  // Rigidbody2D del jugador
    private SpriteRenderer mySpriteRenderer; // SpriteRenderer del jugador
    public GameManager myGameManager;  // Referencia al GameManager para manejar puntajes

    public int maxHealth = 3;          // Vida máxima del jugador
    public int currentHealth;          // Vida actual del jugador

    // Referencia al script PlayerHealth para manejar la salud
    private PlayerHealth playerHealth; 

    // Variables para el disparo
    public GameObject bulletPrefab;     // Prefab de la bala
    public float shootingForce = 10f;   // Fuerza con la que se dispara la bala
    public float shootCooldown = 0.5f;  // Tiempo de espera entre disparos
    private float nextShootTime = 0f;   // Control del tiempo de disparo

    // Para manejar el tiempo de reaparición
    public float respawnWaitTime = 2f; // Tiempo de espera en segundos antes de poder revivir

    private bool isDead = false;  // Flag para saber si el jugador está muerto
    private float respawnTimer = 0f;  // Temporizador para el tiempo de espera

    void Start()
    {
        myRigidbody2D = GetComponent<Rigidbody2D>();  // Obtiene el componente Rigidbody2D
        mySpriteRenderer = GetComponent<SpriteRenderer>();  // Obtiene el componente SpriteRenderer
        StartCoroutine(WalkCoroutine());  // Comienza la animación de caminata
        myGameManager = FindObjectOfType<GameManager>();  // Encuentra el GameManager en la escena

        // Inicializa la vida del jugador
        currentHealth = maxHealth;

        // Obtiene la referencia del script PlayerHealth
        playerHealth = GetComponent<PlayerHealth>();
    }

void Update()
{
    if (isDead)
    {
        // Usa Time.unscaledDeltaTime para que el temporizador funcione incluso si Time.timeScale está pausado
        respawnTimer += Time.unscaledDeltaTime;

        if (respawnTimer >= respawnWaitTime && Input.GetKeyDown(KeyCode.R))
        {
            RespawnPlayer();
        }
        return; // Si está muerto, no procesamos el movimiento ni el disparo
    }

    // Movimiento horizontal
    myRigidbody2D.linearVelocity = new Vector2(playerSpeed * Input.GetAxis("Horizontal"), myRigidbody2D.linearVelocity.y);

    // Salto
    if (Input.GetKeyDown(KeyCode.Space))
    {
        myRigidbody2D.linearVelocity = new Vector2(myRigidbody2D.linearVelocity.x, playerJumpForce);
    }

    // Disparo
    if (Input.GetKeyDown(KeyCode.E) && Time.time >= nextShootTime)
    {
        Shoot();
        nextShootTime = Time.time + shootCooldown; // Resetea el tiempo de disparo
    }
}


    void Shoot()
    {
        // Determina la dirección del disparo según la orientación del jugador
        float direction = mySpriteRenderer.flipX ? -1f : 1f;

        // Instancia la bala en la posición del jugador
        GameObject bullet = Instantiate(bulletPrefab, transform.position, Quaternion.identity); // La bala sale desde la posición del jugador

        Rigidbody2D bulletRb = bullet.GetComponent<Rigidbody2D>();

        // Aplica una fuerza para disparar la bala en la dirección correspondiente
        bulletRb.AddForce(new Vector2(direction, 0f) * shootingForce, ForceMode2D.Impulse); // Dirección horizontal
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("ItemGood"))
        {
            Destroy(collision.gameObject);
            myGameManager.AddScore();  // Aumenta el puntaje
        }
        else if (collision.CompareTag("ItemBad"))
        {
            Destroy(collision.gameObject);
            TakeDamage(1);  // El jugador recibe 1 de daño
        }
        else if (collision.CompareTag("DeathZone"))
        {
            PlayerDeath(); // Llamar al método TakeDamage de PlayerHealth para que el jugador reciba daño
        }
    }

    public void TakeDamage(int damage)
    {
        // Reducir salud
        currentHealth -= damage;

        // Verificar si el jugador ha muerto
        if (currentHealth <= 0)
        {
            PlayerDeath();
        }
        else
        {
            Debug.Log($"Salud restante: {currentHealth}");  // Para depuración
        }
    }

    void PlayerDeath()
    {
        myGameManager.GameOver();  // Llama al método GameOver del GameManager

        // Desactiva al jugador para que no interactúe durante el respawn
        gameObject.SetActive(false);

        // El jugador está muerto, activamos el flag
        isDead = true;

        // Reinicia el temporizador de reaparición
        respawnTimer = 0f;

        Debug.Log("El jugador ha muerto. Espera " + respawnWaitTime + " segundos para revivir.");
    }

    void RespawnPlayer()
    {
        // Reinicia la salud del jugador
        currentHealth = maxHealth;

        // Reubica al jugador en la posición de inicio (modifica esta posición según sea necesario)
        transform.position = new Vector3(0f, 0f, 0f);  // Posición inicial del jugador (ajusta según tu juego)

        // Vuelve a activar al jugador
        gameObject.SetActive(true);

        // Desactiva la muerte
        isDead = false;

        Debug.Log("Jugador ha revivido después de " + respawnWaitTime + " segundos.");
    }

    IEnumerator WalkCoroutine()
    {
        while (true)
        {
            yield return new WaitForSeconds(0.05f);
            mySpriteRenderer.sprite = mySprites[index];
            index = (index + 1) % mySprites.Length; // Usamos módulo para evitar overflow de índice
        }
    }
}

