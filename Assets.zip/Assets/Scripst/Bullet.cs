using UnityEngine;

public class Bullet : MonoBehaviour
{
    public int damage = 1;  // Daño que la bala causa al enemigo

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Verifica si la bala ha colisionado con un objeto con la etiqueta "Enemy"
        if (other.CompareTag("ItemBad"))
        {
            // Obtiene el componente del enemigo para aplicar daño
            Enemy enemy = other.GetComponent<Enemy>();
            if (enemy != null)
            {
                // Aplica el daño al enemigo
                enemy.TakeDamage(damage);
            }

            // Destruye la bala
            Destroy(gameObject);

            // Destruye el enemigo
            Destroy(other.gameObject);
        }
    }
}
