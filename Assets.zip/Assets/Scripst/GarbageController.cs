using UnityEngine;

public class GarbageController : MonoBehaviour
{
    // Este método es llamado cuando otro Collider2D entra en el área de Trigger
    void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log($"Colisión detectada con: {collision.gameObject.name}");

        // Destruye cualquier objeto que entre en el área de Trigger
        Debug.Log($"Destruyendo objeto: {collision.gameObject.name}");
        Destroy(collision.gameObject);
    }
}

