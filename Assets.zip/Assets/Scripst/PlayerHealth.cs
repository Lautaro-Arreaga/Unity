using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerHealth : MonoBehaviour
{
    public int maxHealth = 100;   // Salud máxima del jugador
    public int currentHealth;     // Salud actual del jugador
    public int damage = 10;       // Daño que recibe el jugador
    public Text healthText;       // UI Text para mostrar la salud
    public Text gameOverText;     // Texto que se muestra cuando el jugador muere
    public GameObject restartButton; // Botón para reiniciar el juego
    public GameManager myGameManager; // Referencia al GameManager para manejar puntos

    private void Start()
    {
        currentHealth = maxHealth; // Inicializa la salud del jugador
        UpdateHealthUI();
        
        // Inicializa la UI de Game Over y reinicio
        if (gameOverText != null) gameOverText.gameObject.SetActive(false);
        if (restartButton != null) restartButton.SetActive(false);

        // Asigna el GameManager automáticamente si no está asignado
        if (myGameManager == null) myGameManager = FindObjectOfType<GameManager>();
    }

    public void TakeDamage(int damageAmount)
    {
        currentHealth -= damageAmount; // Reduce la salud por el daño recibido
        if (currentHealth <= 0)
        {
            currentHealth = 0;
            PlayerDeath(); // Llama al método de muerte del jugador
        }
        UpdateHealthUI(); // Actualiza la UI con la nueva salud
    }

    // Actualiza la UI con la salud actual
    void UpdateHealthUI()
    {
        if (healthText != null)
        {
            healthText.text = "Health: " + currentHealth; // Muestra la salud del jugador
        }
    }

    // Maneja la muerte del jugador
    void PlayerDeath()
    {
        // Activa el texto de Game Over y el botón de reinicio
        if (gameOverText != null) gameOverText.gameObject.SetActive(true);
        if (restartButton != null) restartButton.SetActive(true);

        // Pausa el juego cuando el jugador muere
        Time.timeScale = 0f;

        // Llama a la función de Game Over del GameManager
        if (myGameManager != null) myGameManager.GameOver();

        // Reinicia la escena actual después de 2 segundos
        Invoke("RestartScene", 2f);
    }

    // Reinicia la escena actual
    void RestartScene()
    {
        // Vuelve a cargar la escena actual
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}

